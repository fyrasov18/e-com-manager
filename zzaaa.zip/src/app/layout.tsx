import type { Metadata } from "next";
import Link from "next/link";
import { Syne, DM_Mono } from "next/font/google";
import { LayoutDashboard, ShoppingCart, Package, CreditCard, Settings } from "lucide-react";
import "./globals.css";
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";

const syne = Syne({
  subsets: ["latin"],
  variable: "--font-syne",
});

const dmMono = DM_Mono({
  weight: ["400", "500"],
  subsets: ["latin"],
  variable: "--font-dm-mono",
});

const mobileNav = [
  { href: "/", label: "Tableau", icon: LayoutDashboard },
  { href: "/orders", label: "Commandes", icon: ShoppingCart },
  { href: "/products", label: "Produits", icon: Package },
  { href: "/finance", label: "Finance", icon: CreditCard },
  { href: "/settings", label: "Paramètres", icon: Settings },
];

export const metadata: Metadata = {
  title: "Ecom Manager — Tableau de bord e-commerce",
  description: "Plateforme professionnelle de gestion e-commerce: commandes, produits, stock, livraisons, paiements et analytics.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" className="dark">
      <body
        className={`${syne.variable} ${dmMono.variable} font-sans antialiased bg-background text-foreground min-h-screen flex`}
      >
        <Sidebar />
        <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
          <Header />
          <main className="flex-1 overflow-y-auto p-4 lg:p-8">{children}</main>
        </div>
        <div className="lg:hidden fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur-xl px-4 py-2">
          <div className="mx-auto flex max-w-5xl items-center justify-between gap-1">
            {mobileNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="inline-flex min-w-[0] flex-1 flex-col items-center justify-center rounded-3xl px-2 py-2 text-xs font-medium text-muted-foreground hover:bg-muted/20 transition-colors"
              >
                <item.icon className="h-5 w-5" />
                <span className="truncate">{item.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </body>
    </html>
  );
}