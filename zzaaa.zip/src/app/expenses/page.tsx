"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import { Plus, RefreshCw, Edit2, Trash2, X, Calendar, DollarSign, Tag, FileText, TrendingDown, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type Expense = {
  id: string;
  name: string;
  amount: number;
  type: "RECURRING" | "ONE_TIME";
  frequency: "DAILY" | "WEEKLY" | "MONTHLY" | "YEARLY" | null;
  startDate: string;
  category: string;
  description: string | null;
  isActive: boolean;
  createdAt: string;
};

const CATEGORIES = [
  "Abonnements",
  "Outils SaaS",
  "Publicité",
  "Loyer",
  "Services",
  "Logiciels",
  "Frais bancaies",
  "Transport",
  "Autre",
];

const FREQUENCIES = [
  { value: "DAILY", label: "Quotidien" },
  { value: "WEEKLY", label: "Hebdomadaire" },
  { value: "MONTHLY", label: "Mensuel" },
  { value: "YEARLY", label: "Annuel" },
];

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [filter, setFilter] = useState<"ALL" | "RECURRING" | "ONE_TIME">("ALL");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [showModal, setShowModal] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    amount: "",
    type: "RECURRING" as "RECURRING" | "ONE_TIME",
    frequency: "MONTHLY" as "DAILY" | "WEEKLY" | "MONTHLY" | "YEARLY",
    startDate: new Date().toISOString().split("T")[0],
    category: "Abonnements",
    description: "",
  });

  const loadExpenses = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/expenses");
      const data = await res.json();
      
      if (!res.ok) {
        setError(data.error || "Impossible de charger les depenses.");
        setExpenses([]);
      } else if (Array.isArray(data)) {
        setExpenses(data as Expense[]);
      } else {
        setExpenses([]);
      }
    } catch (err) {
      console.error("[Expenses] Load error:", err);
      setError("Erreur lors du chargement.");
      setExpenses([]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadExpenses();
  }, [loadExpenses]);

  const filteredExpenses = useMemo(() => {
    return expenses.filter((e) => {
      if (filter !== "ALL" && e.type !== filter) return false;
      if (categoryFilter !== "ALL" && e.category !== categoryFilter) return false;
      return true;
    });
  }, [expenses, filter, categoryFilter]);

  const recurringExpenses = useMemo(() => filteredExpenses.filter((e) => e.type === "RECURRING"), [filteredExpenses]);
  const oneTimeExpenses = useMemo(() => filteredExpenses.filter((e) => e.type === "ONE_TIME"), [filteredExpenses]);

  const stats = useMemo(() => {
    const totalRecurring = recurringExpenses.reduce((sum, e) => sum + e.amount, 0);
    const monthlyRecurring = recurringExpenses.reduce((sum, e) => {
      switch (e.frequency) {
        case "DAILY": return sum + e.amount * 30;
        case "WEEKLY": return sum + e.amount * 4;
        case "MONTHLY": return sum + e.amount;
        case "YEARLY": return sum + e.amount / 12;
        default: return sum;
      }
    }, 0);
    const totalOneTime = oneTimeExpenses.reduce((sum, e) => sum + e.amount, 0);
    const total = totalRecurring + totalOneTime;

    return { totalRecurring, monthlyRecurring, totalOneTime, total };
  }, [recurringExpenses, oneTimeExpenses]);

  const categories = useMemo(() => {
    const cats = new Set(expenses.map((e) => e.category));
    return ["ALL", ...Array.from(cats)];
  }, [expenses]);

  function openAddModal() {
    setEditingExpense(null);
    setFormData({
      name: "",
      amount: "",
      type: "RECURRING",
      frequency: "MONTHLY",
      startDate: new Date().toISOString().split("T")[0],
      category: "Abonnements",
      description: "",
    });
    setShowModal(true);
  }

  function openEditModal(expense: Expense) {
    setEditingExpense(expense);
    setFormData({
      name: expense.name,
      amount: expense.amount.toString(),
      type: expense.type,
      frequency: expense.frequency as "DAILY" | "WEEKLY" | "MONTHLY" | "YEARLY" || "MONTHLY",
      startDate: new Date(expense.startDate).toISOString().split("T")[0],
      category: expense.category,
      description: expense.description || "",
    });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSuccess("");
    
    if (!formData.name?.trim()) {
      setError("Le nom est requis.");
      return;
    }
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      setError("Le montant doit etre positif.");
      return;
    }
    
    const method = editingExpense ? "PATCH" : "POST";
    const body = editingExpense ? { ...formData, id: editingExpense.id } : formData;

    try {
      const res = await fetch("/api/expenses", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Erreur lors de l'enregistrement.");
        return;
      }

      setSuccess(editingExpense ? "Depense mise a jour." : "Depense ajoutee.");
      setShowModal(false);
      await loadExpenses();
    } catch (err) {
      console.error("[Expenses] Submit error:", err);
      setError("Erreur lors de l'enregistrement.");
    }
  }

async function handleDelete(id: string) {
    if (!confirm("Voulez-vous supprimer cette depense?")) return;
    setError("");
    setSuccess("");

    try {
      const res = await fetch(`/api/expenses?id=${id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Erreur lors de la suppression.");
        return;
      }
      setSuccess("Depense supprimee.");
      await loadExpenses();
    } catch (err) {
      console.error("[Expenses] Delete error:", err);
      setError("Erreur lors de la suppression.");
    }
  }

  async function toggleActive(id: string, currentActive: boolean) {
    setError("");
    try {
      const res = await fetch("/api/expenses", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, isActive: !currentActive }),
      });
      if (res.ok) {
        await loadExpenses();
      } else {
        const data = await res.json();
        setError(data.error || "Erreur lors de la mise a jour.");
      }
    } catch (err) {
      console.error("[Expenses] Toggle error:", err);
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight">Depenses</h1>
          <p className="text-muted-foreground mt-1 text-sm lg:text-base">
            Gere vos depenses recurrentes et ponctuelles.
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-2 text-sm px-4 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity"
        >
          <Plus className="h-4 w-4" />
          Ajouter une depense
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error}
        </div>
      )}
      {success && (
        <div className="rounded-lg border border-primary/30 bg-primary/10 px-4 py-3 text-sm text-primary">
          {success}
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center py-12">
          <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setFilter("ALL")}
          className={cn(
            "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
            filter === "ALL" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
          )}
        >
          Toutes
        </button>
        <button
          onClick={() => setFilter("RECURRING")}
          className={cn(
            "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
            filter === "RECURRING" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
          )}
        >
          Recurrentes
        </button>
        <button
          onClick={() => setFilter("ONE_TIME")}
          className={cn(
            "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
            filter === "ONE_TIME" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
          )}
        >
          Ponctuelles
        </button>
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="px-3 py-1.5 rounded-lg text-sm font-medium bg-muted border-0 focus:ring-2"
        >
          {categories.map((c) => (
            <option key={c} value={c}>{c === "ALL" ? "Toutes categories" : c}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="h-4 w-4 text-rose-500" />
            <p className="text-sm text-muted-foreground">Total depenses</p>
          </div>
          <p className="text-2xl lg:text-3xl font-bold font-mono text-rose-500">
            {stats.total.toFixed(2)} TND
          </p>
        </div>
        <div className="p-5 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2 mb-2">
            <RefreshCw className="h-4 w-4 text-amber-500" />
            <p className="text-sm text-muted-foreground">Recurrentes</p>
          </div>
          <p className="text-2xl lg:text-3xl font-bold font-mono text-amber-500">
            {stats.totalRecurring.toFixed(2)} TND
          </p>
        </div>
        <div className="p-5 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="h-4 w-4 text-blue-500" />
            <p className="text-sm text-muted-foreground">Mensuel estime</p>
          </div>
          <p className="text-2xl lg:text-3xl font-bold font-mono text-blue-500">
            {stats.monthlyRecurring.toFixed(2)} TND
          </p>
        </div>
        <div className="p-5 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4 text-orange-500" />
            <p className="text-sm text-muted-foreground">Ponctuelles</p>
          </div>
          <p className="text-2xl lg:text-3xl font-bold font-mono text-orange-500">
            {stats.totalOneTime.toFixed(2)} TND
          </p>
        </div>
      </div>

      {filter === "ALL" && (
        <div className="space-y-8">
          {recurringExpenses.length > 0 && (
            <div className="rounded-xl border border-border bg-card p-5 lg:p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <RefreshCw className="h-5 w-5 text-amber-500" />
                Depenses recurrentes
                <span className="text-sm text-muted-foreground font-normal">
                  ({recurringExpenses.length})
                </span>
              </h2>
              <div className="space-y-2">
                {recurringExpenses.map((expense) => (
                  <div
                    key={expense.id}
                    className={cn(
                      "flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg border border-border p-4 sm:p-3",
                      !expense.isActive && "opacity-50"
                    )}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{expense.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {FREQUENCIES.find((f) => f.value === expense.frequency)?.label || expense.frequency} &bull; depuis{" "}
                        {new Date(expense.startDate).toLocaleDateString("fr-FR")}
                      </p>
                    </div>
                    <div className="text-xs text-muted-foreground min-w-[100px] hidden sm:block">
                      {expense.category}
                    </div>
                    <div className="text-sm font-mono font-medium min-w-[100px] text-rose-500">
                      -{expense.amount.toFixed(2)} TND
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => toggleActive(expense.id, expense.isActive)}
                        className={cn(
                          "rounded-full px-3 py-1 text-xs font-medium",
                          expense.isActive
                            ? "bg-emerald-500/10 text-emerald-500"
                            : "bg-muted text-muted-foreground"
                        )}
                      >
                        {expense.isActive ? "Actif" : "Inactif"}
                      </button>
                      <button
                        onClick={() => openEditModal(expense)}
                        className="p-2 rounded-lg hover:bg-muted transition-colors"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(expense.id)}
                        className="p-2 rounded-lg hover:bg-destructive/10 text-destructive transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {oneTimeExpenses.length > 0 && (
            <div className="rounded-xl border border-border bg-card p-5 lg:p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                Autres depenses
                <span className="text-sm text-muted-foreground font-normal">
                  ({oneTimeExpenses.length})
                </span>
              </h2>
              <div className="space-y-2">
                {oneTimeExpenses.map((expense) => (
                  <div
                    key={expense.id}
                    className={cn(
                      "flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg border border-border p-4 sm:p-3",
                      !expense.isActive && "opacity-50"
                    )}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{expense.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(expense.startDate).toLocaleDateString("fr-FR")}
                        {expense.description && ` &bull; ${expense.description}`}
                      </p>
                    </div>
                    <div className="text-xs text-muted-foreground min-w-[100px] hidden sm:block">
                      {expense.category}
                    </div>
                    <div className="text-sm font-mono font-medium min-w-[100px] text-rose-500">
                      -{expense.amount.toFixed(2)} TND
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => toggleActive(expense.id, expense.isActive)}
                        className={cn(
                          "rounded-full px-3 py-1 text-xs font-medium",
                          expense.isActive
                            ? "bg-emerald-500/10 text-emerald-500"
                            : "bg-muted text-muted-foreground"
                        )}
                      >
                        {expense.isActive ? "Actif" : "Inactif"}
                      </button>
                      <button
                        onClick={() => openEditModal(expense)}
                        className="p-2 rounded-lg hover:bg-muted transition-colors"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(expense.id)}
                        className="p-2 rounded-lg hover:bg-destructive/10 text-destructive transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {filter !== "ALL" && (
        <div className="rounded-xl border border-border bg-card p-5 lg:p-6">
          <div className="space-y-2">
            {filteredExpenses.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">
               Aucune depense trouvee.
              </p>
            ) : (
              filteredExpenses.map((expense) => (
                <div
                  key={expense.id}
                  className={cn(
                    "flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg border border-border p-4 sm:p-3",
                    !expense.isActive && "opacity-50"
                  )}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{expense.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {expense.type === "RECURRING"
                        ? `${FREQUENCIES.find((f) => f.value === expense.frequency)?.label || expense.frequency} &bull; depuis `
                        : ""}
                      {new Date(expense.startDate).toLocaleDateString("fr-FR")}
                      {expense.description && ` &bull; ${expense.description}`}
                    </p>
                  </div>
                  <div className="text-xs text-muted-foreground min-w-[100px] hidden sm:block">
                    {expense.category}
                  </div>
                  <div className="text-sm font-mono font-medium min-w-[100px] text-rose-500">
                    -{expense.amount.toFixed(2)} TND
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => toggleActive(expense.id, expense.isActive)}
                      className={cn(
                        "rounded-full px-3 py-1 text-xs font-medium",
                        expense.isActive
                          ? "bg-emerald-500/10 text-emerald-500"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {expense.isActive ? "Actif" : "Inactif"}
                    </button>
                    <button
                      onClick={() => openEditModal(expense)}
                      className="p-2 rounded-lg hover:bg-muted transition-colors"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(expense.id)}
                      className="p-2 rounded-lg hover:bg-destructive/10 text-destructive transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-xl bg-card border border-border p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                {editingExpense ? "Modifier la depense" : "Ajouter une depense"}
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 rounded-lg hover:bg-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Nom</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-background border border-border focus:border-primary focus:outline-none"
                  placeholder="Nom de la depense"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Montant (TND)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-background border border-border focus:border-primary focus:outline-none"
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Date</label>
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-background border border-border focus:border-primary focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-1.5 block">Type</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, type: "RECURRING" })}
                    className={cn(
                      "flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                      formData.type === "RECURRING"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    )}
                  >
                    Recurrente
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, type: "ONE_TIME" })}
                    className={cn(
                      "flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                      formData.type === "ONE_TIME"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    )}
                  >
                    Ponctuelle
                  </button>
                </div>
              </div>

              {formData.type === "RECURRING" && (
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Frequence</label>
                  <select
                    value={formData.frequency}
                    onChange={(e) => setFormData({ ...formData, frequency: e.target.value as "DAILY" | "WEEKLY" | "MONTHLY" | "YEARLY" })}
                    className="w-full px-3 py-2 rounded-lg bg-background border border-border focus:border-primary focus:outline-none"
                  >
                    {FREQUENCIES.map((f) => (
                      <option key={f.value} value={f.value}>{f.label}</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="text-sm font-medium mb-1.5 block">Categorie</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-background border border-border focus:border-primary focus:outline-none"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-medium mb-1.5 block">Description (optionnel)</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-background border border-border focus:border-primary focus:outline-none resize-none"
                  rows={2}
                  placeholder="Details supplementaires..."
                />
              </div>

              <button
                type="submit"
                className="w-full px-4 py-2.5 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity"
              >
                {editingExpense ? "Mettre a jour" : "Ajouter"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}