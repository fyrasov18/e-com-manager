"use client";

import { FormEvent, useEffect, useState, useCallback } from "react";
import { Truck, Plus, TestTube, Trash2, X, CheckCircle, AlertCircle, ExternalLink, RefreshCw, Upload, Package } from "lucide-react";
import { cn } from "@/lib/utils";

type InstaConfig = {
  configured: boolean;
  isActive: boolean;
  lastTested: string | null;
  lastError: string | null;
};

type ConfirmState = {
  show: boolean;
};

export default function InstaDeliveryPage() {
  const [config, setConfig] = useState<InstaConfig | null>(null);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<ConfirmState>({ show: false });
  const [deleting, setDeleting] = useState(false);
  const [importText, setImportText] = useState("");
  const [importResult, setImportResult] = useState<{ imported: number; updated: number; failed: number; details: { tracking: string; status: string; error?: string }[] } | null>(null);
  const [form, setForm] = useState({
    login: "",
    password: "",
  });

  const loadConfig = useCallback(async () => {
    const res = await fetch("/api/insta-delivery");
    if (!res.ok) return;
    const data = (await res.json()) as InstaConfig;
    setConfig(data);
    if (data.configured) {
      setForm((prev) => ({ ...prev, login: "***configured***" }));
    }
  }, []);

  useEffect(() => {
    setTimeout(() => { loadConfig(); }, 0);
  }, [loadConfig]);

  async function handleSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!form.login || !form.password) {
      setError("Login et password requis");
      return;
    }
    if (form.login === "***configured***") {
      setError("Entrez un nouveau mot de passe pour mettre à jour");
      return;
    }

    setLoading(true);
    setError("");
    setMessage("");

    const res = await fetch("/api/insta-delivery", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, action: "save" }),
    });

    const payload = await res.json().catch(() => ({}));
    if (!res.ok || !payload.success) {
      setError(payload.message ?? "Enregistrement échoué.");
      setLoading(false);
      return;
    }

    setMessage(payload.message ?? "Configuration enregistrée.");
    setForm((prev) => ({ ...prev, password: "" }));
    await loadConfig();
    setLoading(false);
  }

  async function testConnection() {
    setTesting(true);
    setError("");
    setMessage("");

    const res = await fetch("/api/insta-delivery", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "test" }),
    });

    const payload = await res.json().catch(() => ({}));
    if (!res.ok || !payload.success) {
      setError(payload.message ?? "Test échoué.");
      setTesting(false);
      return;
    }

    setMessage(payload.message ?? "Connexion réussie!");
    await loadConfig();
    setTesting(false);
  }

  async function handleDelete() {
    setDeleting(true);
    setError("");

    try {
      const res = await fetch("/api/insta-delivery", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "delete" }),
      });

      const payload = await res.json().catch(() => ({}));
      if (!res.ok || !payload.success) {
        setError(payload.message ?? "Erreur lors de la suppression.");
        setConfirmDelete({ show: false });
        setDeleting(false);
        return;
      }

      setMessage(payload.message ?? "Configuration supprimée.");
      setForm({ login: "", password: "" });
      setConfig(null);
      setConfirmDelete({ show: false });
    } catch {
      setError("Erreur lors de la suppression.");
    }

    setDeleting(false);
  }

  async function handleImport() {
    if (!importText.trim()) {
      setError("Entrez des numéros de tracking");
      return;
    }

    const trackingNumbers = importText.split(/[\n,]+/).map((t) => t.trim()).filter(Boolean);
    if (trackingNumbers.length === 0) {
      setError("Aucun numéro de tracking valide");
      return;
    }

    setImporting(true);
    setError("");
    setMessage("");
    setImportResult(null);

    try {
      const res = await fetch("/api/insta-delivery/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trackingNumbers }),
      });

      const payload = await res.json().catch(() => ({}));
      if (!res.ok || !payload.success) {
        setError(payload.message ?? "Import échoué.");
        setImporting(false);
        return;
      }

      setMessage(payload.message ?? "Import terminé!");
      setImportResult(payload.results);
      setImportText("");
    } catch {
      setError("Erreur lors de l'import");
    }

    setImporting(false);
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
              <Truck className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold tracking-tight">
                InstaDelivery
              </h1>
              <p className="text-muted-foreground mt-1 text-sm lg:text-base">
                Configuration de l&apos;API de livraison.
              </p>
            </div>
          </div>
        </div>
        {config?.configured && (
          <a
            href="https://app.insta-delivery.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm text-primary hover:underline"
          >
            <ExternalLink className="h-4 w-4" />
            Voir dashboard InstaDelivery
          </a>
        )}
      </div>

      {error && (
        <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive flex items-center gap-2">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}
      {message && (
        <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
          <CheckCircle className="h-4 w-4 shrink-0" />
          {message}
        </div>
      )}

      <div className="rounded-xl border border-border bg-card p-5 lg:p-6">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Plus className="h-5 w-5" />
          {config?.configured ? "Mettre à jour la configuration" : "Configurer InstaDelivery"}
        </h2>
        
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Login API</label>
            <input
              type="text"
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring/50 focus:border-ring transition-colors"
              placeholder="Votre login InstaDelivery"
              value={form.login}
              onChange={(e) => setForm((prev) => ({ ...prev, login: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Mot de passe API</label>
            <input
              type="password"
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring/50 focus:border-ring transition-colors"
              placeholder={config?.configured ? "Nouveau mot de passe (laisser vide pour conserver)" : "Votre mot de passe InstaDelivery"}
              value={form.password}
              onChange={(e) => setForm((prev) => ({ ...prev, password: e.target.value }))}
              required
            />
          </div>
          
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 rounded-lg bg-primary text-primary-foreground px-4 py-2.5 font-medium hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Plus className="h-4 w-4" />
              {loading ? "Enregistrement..." : config?.configured ? "Mettre à jour" : "Enregistrer"}
            </button>
            
            {config?.configured && (
              <>
                <button
                  type="button"
                  onClick={testConnection}
                  disabled={testing}
                  className="flex-1 rounded-lg border border-input bg-background px-4 py-2.5 font-medium hover:bg-accent transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <TestTube className="h-4 w-4" />
                  {testing ? "Test..." : "Tester"}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete({ show: true })}
                  className="px-4 py-2.5 rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-500/20 transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </>
            )}
          </div>
        </form>

        {config?.configured && (
          <div className="mt-6 pt-6 border-t border-border">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <span className="text-muted-foreground">Statut:</span>
                <span className={cn(
                  "font-medium",
                  config.isActive ? "text-emerald-500" : "text-muted-foreground"
                )}>
                  {config.isActive ? "Actif" : "Inactif"}
                </span>
              </div>
              {config.lastTested && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <RefreshCw className="h-3 w-3" />
                  Dernier test: {new Date(config.lastTested).toLocaleString("fr-FR")}
                </div>
              )}
            </div>
            {config.lastError && (
              <div className="mt-3 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                Dernière erreur: {config.lastError}
              </div>
            )}
          </div>
        )}
      </div>

      {config?.configured && (
        <div className="rounded-xl border border-border bg-card p-5 lg:p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Importer d&apos;anciennes commandes
          </h2>
          <p className="text-sm text-muted-foreground mb-4">
            Collez une liste de numéros de tracking (un par ligne ou séparés par des virgules) pour récupérer les commandes avec leur statut.
          </p>
          <textarea
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm font-mono min-h-[120px] outline-none focus:ring-2 focus:ring-ring/50 focus:border-ring transition-colors"
            placeholder="TRACKING123&#10;TRACKING456&#10;TRACKING789"
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
          />
          <div className="flex gap-3 mt-4">
            <button
              onClick={handleImport}
              disabled={importing || !importText.trim()}
              className="flex-1 rounded-lg bg-primary text-primary-foreground px-4 py-2.5 font-medium hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {importing ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Import en cours...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4" />
                  Importer les commandes
                </>
              )}
            </button>
          </div>
          {importResult && (
            <div className="mt-4 p-4 rounded-lg bg-muted/50 space-y-2">
              <div className="flex items-center gap-4 text-sm">
                <span className="flex items-center gap-1 text-emerald-500">
                  <CheckCircle className="h-4 w-4" />
                  {importResult.imported} importées
                </span>
                <span className="flex items-center gap-1 text-blue-500">
                  <Package className="h-4 w-4" />
                  {importResult.updated} mises à jour
                </span>
                <span className="flex items-center gap-1 text-rose-500">
                  <AlertCircle className="h-4 w-4" />
                  {importResult.failed} échouées
                </span>
              </div>
              {importResult.details.slice(0, 10).map((item, idx) => (
                <div key={idx} className="text-xs font-mono flex items-center gap-2">
                  <span className={item.error ? "text-rose-500" : "text-muted-foreground"}>
                    {item.tracking}
                  </span>
                  <span className="text-muted-foreground">→</span>
                  <span className={item.error ? "text-rose-400" : "text-emerald-500"}>
                    {item.error || item.status}
                  </span>
                </div>
              ))}
              {importResult.details.length > 10 && (
                <p className="text-xs text-muted-foreground">
                  ...et {importResult.details.length - 10} autres
                </p>
              )}
            </div>
          )}
        </div>
      )}

      {confirmDelete.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-xl border border-border bg-card p-6">
            <h3 className="text-lg font-semibold mb-4">Confirmer la suppression</h3>
            <p className="text-muted-foreground mb-6">
              Êtes-vous sûr de vouloir supprimer la configuration InstaDelivery ? Cette action est irréversible.
            </p>
            <div className="flex gap-3">
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="flex-1 rounded-lg bg-rose-600 text-white px-4 py-2.5 font-medium hover:bg-rose-700 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Trash2 className="h-4 w-4" />
                {deleting ? "Suppression..." : "Confirmer"}
              </button>
              <button
                onClick={() => setConfirmDelete({ show: false })}
                className="flex-1 rounded-lg border border-input bg-background px-4 py-2.5 font-medium hover:bg-accent flex items-center justify-center gap-2"
              >
                <X className="h-4 w-4" />
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}