import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { saveInstaDeliveryConfig, deleteInstaDeliveryConfig, testInstaDeliveryConnection, getInstaDeliveryConfig } from "@/lib/instavia-delivery";

export async function GET() {
  try {
    const teams = await prisma.team.findMany({ take: 1 });
    if (teams.length === 0) {
      return NextResponse.json({ configured: false, message: "Aucune équipe trouvée" });
    }
    const teamId = teams[0].id;
    const config = await getInstaDeliveryConfig(teamId);
    
    return NextResponse.json({
      configured: !!config,
      isActive: config?.isActive ?? false,
      lastTested: config?.lastTested?.toISOString() ?? null,
      lastError: config?.lastError ?? null,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Erreur serveur";
    console.error("InstaDelivery GET error:", err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { login, password, action } = body;

    const teams = await prisma.team.findMany({ take: 1 });
    if (teams.length === 0) {
      return NextResponse.json({ success: false, message: "Aucune équipe trouvée" }, { status: 400 });
    }
    const teamId = teams[0].id;

    if (action === "save") {
      if (!login || !password) {
        return NextResponse.json({ success: false, message: "Login et password requis" }, { status: 400 });
      }
      return NextResponse.json(await saveInstaDeliveryConfig(teamId, login, password));
    }

    if (action === "delete") {
      return NextResponse.json(await deleteInstaDeliveryConfig(teamId));
    }

    if (action === "test") {
      return NextResponse.json(await testInstaDeliveryConnection(teamId));
    }

    return NextResponse.json({ success: false, message: "Action inconnue" }, { status: 400 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Erreur serveur";
    console.error("InstaDelivery POST error:", err);
    return NextResponse.json({ success: false, message }, { status: 500 });
  }
}