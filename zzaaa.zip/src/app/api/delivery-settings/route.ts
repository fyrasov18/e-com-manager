import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

const DEFAULT_PROVIDERS = ["COLISSIMO", "INSTADELIVERY"];

export async function GET() {
  try {
    for (const provider of DEFAULT_PROVIDERS) {
      await prisma.deliveryCompanySetting.upsert({
        where: { provider },
        update: {},
        create: {
          provider,
          deliveryCost: 8,
          returnCost: 3,
        },
      });
    }

    const settings = await prisma.deliveryCompanySetting.findMany({
      orderBy: {
        provider: "asc",
      },
    });

    return NextResponse.json({
      success: true,
      settings,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Erreur chargement paramètres livraison",
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();

    const provider = String(body.provider ?? "").trim();
    const deliveryCost = Number(body.deliveryCost);
    const returnCost = Number(body.returnCost);

    if (!provider) {
      return NextResponse.json(
        { success: false, message: "Société livraison obligatoire" },
        { status: 400 }
      );
    }

    if (Number.isNaN(deliveryCost) || Number.isNaN(returnCost)) {
      return NextResponse.json(
        { success: false, message: "Coûts invalides" },
        { status: 400 }
      );
    }

    const setting = await prisma.deliveryCompanySetting.upsert({
      where: { provider },
      update: {
        deliveryCost,
        returnCost,
      },
      create: {
        provider,
        deliveryCost,
        returnCost,
      },
    });

    return NextResponse.json({
      success: true,
      data: setting,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Erreur modification paramètres livraison",
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
