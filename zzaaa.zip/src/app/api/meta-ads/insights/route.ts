import { NextResponse } from "next/server";
import { fetchMetaCampaignInsights } from "@/lib/meta-ads";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      accessToken?: string;
      adAccountId?: string;
      since?: string;
      until?: string;
    };

    const accessToken = body.accessToken?.trim();
    const adAccountId = body.adAccountId?.trim();
    const since = body.since?.trim();
    const until = body.until?.trim();

    if (!accessToken || !adAccountId || !since || !until) {
      return NextResponse.json(
        { error: "accessToken, adAccountId, since, until are required." },
        { status: 400 }
      );
    }

    const campaigns = await fetchMetaCampaignInsights({
      accessToken,
      adAccountId,
      since,
      until,
    });

    const totals = campaigns.reduce(
      (acc, campaign) => {
        acc.spend += Number(campaign.spend ?? "0");
        acc.clicks += Number(campaign.clicks ?? "0");
        acc.impressions += Number(campaign.impressions ?? "0");
        return acc;
      },
      { spend: 0, clicks: 0, impressions: 0 }
    );

    return NextResponse.json({
      totals,
      campaigns,
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Failed to fetch Meta Ads insights.",
      },
      { status: 500 }
    );
  }
}
