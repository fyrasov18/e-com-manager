import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getOrCreateDefaultTeamId } from "@/lib/default-team";

export async function GET() {
  try {
    const teamId = await getOrCreateDefaultTeamId();
    
    const expenses = await prisma.expense.findMany({
      where: { teamId },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(expenses);
  } catch (err) {
    console.error("[Expense] GET error:", err);
    return NextResponse.json({ error: "Impossible de charger les depenses." }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const teamId = await getOrCreateDefaultTeamId();
    const body = await request.json();

    const { name, amount, type, frequency, startDate, category, description } = body;

    if (!name || !amount || !type || !category) {
      return NextResponse.json({ error: "Champs requis manquants." }, { status: 400 });
    }

    if (!["RECURRING", "ONE_TIME"].includes(type)) {
      return NextResponse.json({ error: "Type invalide." }, { status: 400 });
    }

    if (type === "RECURRING" && !["DAILY", "WEEKLY", "MONTHLY", "YEARLY"].includes(frequency)) {
      return NextResponse.json({ error: "Frequence invalide." }, { status: 400 });
    }

    const expense = await prisma.expense.create({
      data: {
        name,
        amount: parseFloat(amount),
        type,
        frequency: type === "RECURRING" ? frequency : null,
        startDate: startDate ? new Date(startDate) : new Date(),
        category,
        description: description || null,
        teamId,
      },
    });

    console.log("[Expense] Created:", expense.id, expense.name);
    return NextResponse.json(expense);
  } catch (err) {
    console.error("[Expense] POST error:", err);
    return NextResponse.json({ error: "Erreur lors de la creation." }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const teamId = await getOrCreateDefaultTeamId();
    const body = await request.json();

    const { id, name, amount, type, frequency, startDate, category, description, isActive } = body;

    if (!id) {
      return NextResponse.json({ error: "ID requis." }, { status: 400 });
    }

    const existing = await prisma.expense.findFirst({
      where: { id, teamId },
    });

    if (!existing) {
      return NextResponse.json({ error: "Depense non trouvee." }, { status: 404 });
    }

    const updateData: Record<string, any> = {};
    if (name !== undefined) updateData.name = name;
    if (amount !== undefined) updateData.amount = parseFloat(amount);
    if (type !== undefined) updateData.type = type;
    if (frequency !== undefined) updateData.frequency = frequency;
    if (startDate !== undefined) updateData.startDate = new Date(startDate);
    if (category !== undefined) updateData.category = category;
    if (description !== undefined) updateData.description = description;
    if (isActive !== undefined) updateData.isActive = isActive;

    const expense = await prisma.expense.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json(expense);
  } catch (err) {
    console.error("[Expense] PATCH error:", err);
    return NextResponse.json({ error: "Erreur lors de la mise a jour." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const teamId = await getOrCreateDefaultTeamId();
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID requis." }, { status: 400 });
    }

    const existing = await prisma.expense.findFirst({
      where: { id, teamId },
    });

    if (!existing) {
      return NextResponse.json({ error: "Depense non trouvee." }, { status: 404 });
    }

    await prisma.expense.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[Expense] DELETE error:", err);
    return NextResponse.json({ error: "Erreur lors de la suppression." }, { status: 500 });
  }
}