import { NextRequest, NextResponse } from "next/server";

/**
 * GET /api/cron/sync-delivery
 * Protected by CRON_SECRET header.
 * Call this every minute via external cron (cron-job.org, Vercel cron, etc.)
 *
 * Example vercel.json:
 * { "crons": [{ "path": "/api/cron/sync-delivery", "schedule": "* * * * *" }] }
 */
export async function GET(req: NextRequest) {
  const secret = req.headers.get("x-cron-secret") ?? req.nextUrl.searchParams.get("secret");
  const expected = process.env.CRON_SECRET;

  if (expected && secret !== expected) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { getOrCreateDefaultTeamId } = await import("@/lib/default-team");
    const { syncDeliveryCompanies, getSyncStatus } = await import("@/lib/sync-delivery");

    const teamId = await getOrCreateDefaultTeamId();
    const status = getSyncStatus();

    if (status.isSyncing) {
      return NextResponse.json({ skipped: true, reason: "already_running" });
    }

    // Fire and forget — cron doesn't need to wait for full result
    syncDeliveryCompanies(teamId).catch(e =>
      console.error("[Cron/sync-delivery] Error:", e)
    );

    return NextResponse.json({ triggered: true, teamId, at: new Date().toISOString() });
  } catch (err) {
    console.error("[Cron/sync-delivery]", err);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
