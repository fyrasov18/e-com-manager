"use client";

import { Bell, Search, User, ChevronDown, LogOut, Settings } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function Header() {
  const [userOpen, setUserOpen] = useState(false);

  return (
    <header className="h-16 border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-30 px-4 lg:px-8 flex items-center justify-between gap-4">
      <div className="flex items-center gap-4 flex-1 pl-10 lg:pl-0">
        <div className="relative w-full max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-muted-foreground" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-input rounded-xl text-sm bg-background/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/30 focus:border-ring transition-all"
            placeholder="Rechercher commandes, produits, clients..."
          />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button className="relative p-2.5 rounded-xl text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors">
          <Bell className="h-5 w-5" />
          <span className="absolute top-2 right-2 block h-2 w-2 rounded-full bg-primary ring-2 ring-background" />
        </button>
        
        <div className="relative">
          <button 
            onClick={() => setUserOpen(!userOpen)}
            className="flex items-center gap-2 p-1.5 pr-3 rounded-xl hover:bg-accent/50 transition-colors"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-emerald-400 flex items-center justify-center">
              <User className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-medium hidden sm:block">Jody</span>
            <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", userOpen && "rotate-180")} />
          </button>
          
          {userOpen && (
            <div className="absolute right-0 top-full mt-2 w-48 py-2 rounded-xl border border-border bg-card/95 backdrop-blur-xl shadow-xl">
              <div className="px-3 py-2 border-b border-border">
                <p className="text-sm font-medium">Jody Manager</p>
                <p className="text-xs text-muted-foreground">admin@ecom.tn</p>
              </div>
              <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors">
                <Settings className="h-4 w-4" />
                Paramètres
              </button>
              <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-rose-400 hover:bg-rose-500/10 transition-colors">
                <LogOut className="h-4 w-4" />
                Déconnexion
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}