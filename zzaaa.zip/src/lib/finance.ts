import { prisma } from "@/lib/prisma";

export type DeliverySettings = {
  deliveryCost: number;
  returnCost: number;
};

export type FinanceInput = {
  totalAmount: number;
  status: string | null | undefined;
  settings: DeliverySettings;
};

export type FinanceResult = {
  validatedRevenue: number;
  deliveryCostApplied: number;
  returnCostApplied: number;
  netProfit: number;
};

export function normalizeStatus(status: string | null | undefined): string {
  return String(status ?? "")
    .trim()
    .toUpperCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export function isDeliveredStatus(status: string | null | undefined): boolean {
  return ["LIVRE", "LIVREE", "DELIVERED", "PAID_DELIVERED", "DELIVERED_TO_CUSTOMER"].includes(
    normalizeStatus(status)
  );
}

export function isReturnStatus(status: string | null | undefined): boolean {
  return [
    "RETOUR",
    "RETOUR_RECU",
    "RETOUR_RECUPERE",
    "RETOUR_LIVRE",
    "ANOMALIE",
    "ECHEC",
    "FAILED",
    "RETURNED",
  ].includes(normalizeStatus(status));
}

export function toNumber(value: unknown): number {
  const numberValue = Number(value ?? 0);
  return Number.isFinite(numberValue) ? numberValue : 0;
}

/**
 * Calcule les métriques financières d'une commande individuelle
 */
export function calculateOrderFinance(input: FinanceInput & { purchaseCost?: number }): FinanceResult {
  const revenue = Number(input.totalAmount || 0);
  const deliveryCost = Number(input.settings.deliveryCost || 8);
  const returnCost = Number(input.settings.returnCost || 3);
  const purchaseCost = Number(input.purchaseCost || 0);

  if (isDeliveredStatus(input.status)) {
    return {
      validatedRevenue: revenue,
      deliveryCostApplied: deliveryCost,
      returnCostApplied: 0,
      netProfit: revenue - deliveryCost - purchaseCost,
    };
  }

  if (isReturnStatus(input.status)) {
    return {
      validatedRevenue: 0,
      deliveryCostApplied: 0,
      returnCostApplied: returnCost,
      netProfit: -returnCost,
    };
  }

  return {
    validatedRevenue: 0,
    deliveryCostApplied: 0,
    returnCostApplied: 0,
    netProfit: 0,
  };
}

/**
 * Récupère les paramètres de coût pour une société de livraison
 */
export async function getFinanceSettings(teamId: string, provider: string) {
  const setting = await prisma.deliveryCompanySetting.findUnique({
    where: { provider }
  });
  
  if (setting) {
    return {
      deliveryCost: setting.deliveryCost,
      returnCost: setting.returnCost,
    };
  }
  return { deliveryCost: 8, returnCost: 3 };
}

/**
 * Calcule les métriques globales selon la nouvelle logique métier
 */
export async function calculateFinanceMetrics(teamId: string, startDate?: Date, endDate?: Date) {
  const dateFilter = (startDate || endDate) ? {
    ...(startDate && { gte: startDate }),
    ...(endDate && { lte: endDate })
  } : undefined;

  const [allOrders, expenses, transactions] = await Promise.all([
    prisma.order.findMany({
      where: {
        teamId,
        ...(dateFilter && {
          OR: [
            { operationDate: dateFilter },
            { operationDate: null, deliveredAt: dateFilter },
            { operationDate: null, deliveredAt: null, returnedAt: dateFilter },
            { operationDate: null, deliveredAt: null, returnedAt: null, date: dateFilter }
          ]
        })
      }
    }),
    prisma.expense.findMany({
      where: { teamId, isActive: true, ...(dateFilter && { createdAt: dateFilter }) }
    }),
    prisma.transaction.findMany({
      where: { teamId, type: "EXPENSE", ...(dateFilter && { date: dateFilter }) }
    })
  ]);

  const deliveredOrders = allOrders.filter(o => isDeliveredStatus(o.status));
  const returnedOrders = allOrders.filter(o => isReturnStatus(o.status));

  // Logique fournie par l'utilisateur
  const chiffreAffaires = deliveredOrders.reduce(
    (sum, order) => sum + toNumber(order.revenue),
    0
  );

  const totalDeliveryFees = allOrders.reduce(
    (sum, order) => sum + toNumber(order.deliveryCostApplied),
    0
  );

  const totalReturnFees = allOrders.reduce(
    (sum, order) => sum + toNumber(order.returnCostApplied),
    0
  );

  const totalProductCosts = deliveredOrders.reduce(
    (sum, order) => sum + toNumber(order.cost),
    0
  );

  const otherExpenses = 
    expenses.reduce((sum, e) => sum + toNumber(e.amount), 0) +
    transactions.reduce((sum, t) => sum + toNumber(t.amount), 0);

  const totalExpenses =
    totalDeliveryFees + totalReturnFees + totalProductCosts + otherExpenses;

  const netProfit = chiffreAffaires - totalExpenses;

  const totalValidatedCA = netProfit;
  const paidAmount = totalValidatedCA;
  const remainingAmount = netProfit - paidAmount;

  // Stats par prestataire
  const providerMap = new Map<string, any>();
  for (const o of allOrders) {
    const providerRaw = (o.shippingProvider || "AUTRE").toUpperCase();
    let provider = "AUTRE";
    if (providerRaw.includes("COLISSIMO")) provider = "COLISSIMO";
    else if (providerRaw.includes("INSTA")) provider = "INSTADELIVERY";

    if (!providerMap.has(provider)) {
      providerMap.set(provider, {
        provider,
        chiffreAffaires: 0,
        deliveryFees: 0,
        returnFees: 0,
        productCosts: 0,
        netProfit: 0,
        orderCount: 0,
        deliveredCount: 0,
        returnedCount: 0
      });
    }
    const pData = providerMap.get(provider);
    pData.orderCount++;
    pData.deliveryFees += toNumber(o.deliveryCostApplied);
    pData.returnFees += toNumber(o.returnCostApplied);

    if (isDeliveredStatus(o.status)) {
      pData.deliveredCount++;
      pData.chiffreAffaires += toNumber(o.revenue);
      pData.productCosts += toNumber(o.cost);
    } else if (isReturnStatus(o.status)) {
      pData.returnedCount++;
    }
  }

  // Calculer netProfit par provider
  const byProvider = Array.from(providerMap.values()).map(p => {
    p.netProfit = p.chiffreAffaires - (p.deliveryFees + p.returnFees + p.productCosts);
    return p;
  });

  return {
    chiffreAffaires,
    totalRevenue: chiffreAffaires,
    totalValidatedCA,
    netProfit,
    totalDeliveryFees,
    totalReturnFees,
    totalProductCosts,
    otherExpenses,
    totalExpenses,
    paidAmount,
    remainingAmount,
    deliveredOrdersCount: deliveredOrders.length,
    returnedOrdersCount: returnedOrders.length,
    totalOrdersCount: allOrders.length,
    byProvider
  };
}
