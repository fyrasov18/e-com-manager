type MetaInsightsParams = {
  accessToken: string;
  adAccountId: string;
  since: string;
  until: string;
};

export type MetaCampaignInsight = {
  campaign_id: string;
  campaign_name: string;
  impressions: string;
  clicks: string;
  spend: string;
  ctr: string;
  cpc?: string;
  cpm?: string;
  actions?: Array<{ action_type: string; value: string }>;
};

export async function fetchMetaCampaignInsights(params: MetaInsightsParams) {
  const accountId = params.adAccountId.startsWith("act_")
    ? params.adAccountId
    : `act_${params.adAccountId}`;

  const fields = [
    "campaign_id",
    "campaign_name",
    "impressions",
    "clicks",
    "spend",
    "ctr",
    "cpc",
    "cpm",
    "actions",
  ].join(",");

  const timeRange = encodeURIComponent(
    JSON.stringify({ since: params.since, until: params.until })
  );

  const url = `https://graph.facebook.com/v23.0/${accountId}/insights?level=campaign&fields=${fields}&time_range=${timeRange}&limit=100&access_token=${encodeURIComponent(
    params.accessToken
  )}`;

  const res = await fetch(url, {
    method: "GET",
    cache: "no-store",
  });

  const payload = await res.json();
  if (!res.ok) {
    const message =
      payload?.error?.message ??
      "Meta Ads API error while fetching campaign insights.";
    throw new Error(message);
  }

  return (payload?.data ?? []) as MetaCampaignInsight[];
}
