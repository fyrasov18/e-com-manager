// src/middleware.ts
// Protège toutes les routes /admin sauf /admin/login

import { auth } from "@/lib/auth";
import { NextResponse } from "next/server";

export default auth((req) => {
  const { pathname } = req.nextUrl;

  const isAdminRoute = pathname.startsWith("/admin");
  const isLoginPage = pathname === "/admin/login";
  const isAuthenticated = !!req.auth;
  const isAdmin = (req.auth?.user as { role?: string })?.role === "ADMIN";

  // Rediriger vers login si pas authentifié sur une route admin
  if (isAdminRoute && !isLoginPage && !isAuthenticated) {
    return NextResponse.redirect(new URL("/admin/login", req.url));
  }

  // Rediriger vers login si authentifié mais pas admin
  if (isAdminRoute && !isLoginPage && isAuthenticated && !isAdmin) {
    return NextResponse.redirect(new URL("/admin/login", req.url));
  }

  // Rediriger vers dashboard si déjà connecté et tente d'accéder au login
  if (isLoginPage && isAuthenticated && isAdmin) {
    return NextResponse.redirect(new URL("/admin", req.url));
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/admin/:path*"],
};
